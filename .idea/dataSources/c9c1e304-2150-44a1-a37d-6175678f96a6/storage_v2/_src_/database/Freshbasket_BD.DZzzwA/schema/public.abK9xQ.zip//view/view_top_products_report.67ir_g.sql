create view view_top_products_report(product_id, product_name, total_units_sold, total_revenue) as
SELECT p.product_id,
       p.name                                   AS product_name,
       sum(sd.quantity)                         AS total_units_sold,
       sum(sd.quantity::numeric * sd.unit_cost) AS total_revenue
FROM sale_details sd
         JOIN sales s ON sd.sale_id = s.sale_id
         JOIN products p ON sd.product_id = p.product_id
WHERE s.active = true
  AND sd.active = true
  AND s.status::text = 'Completada'::text
GROUP BY p.product_id, p.name
ORDER BY (sum(sd.quantity)) DESC;

alter table view_top_products_report
    owner to postgres;

