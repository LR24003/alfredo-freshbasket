create view view_suppliers_report
            (supplier_id, supplier_name, country, main_product, supplied_volume, total_products, total_stock,
             total_purchased) as
WITH ranked_products AS (SELECT products.supplier_id,
                                products.name                                                                                      AS product_name,
                                products.current_stock,
                                row_number()
                                OVER (PARTITION BY products.supplier_id ORDER BY products.current_stock DESC, products.product_id) AS rn
                         FROM products
                         WHERE products.active = true),
     supplier_stats AS (SELECT products.supplier_id,
                               count(products.product_id)                            AS total_products,
                               sum(products.current_stock)                           AS total_units_supplied,
                               sum(products.price * products.current_stock::numeric) AS total_inventory_value
                        FROM products
                        WHERE products.active = true
                        GROUP BY products.supplier_id)
SELECT s.supplier_id,
       TRIM(BOTH FROM concat(s.name, ' ', s.last_name))              AS supplier_name,
       COALESCE(c.name, 'No Especificado'::character varying)        AS country,
       COALESCE(rp.product_name, 'Sin Productos'::character varying) AS main_product,
       COALESCE(rp.current_stock, 0)                                 AS supplied_volume,
       COALESCE(st.total_products, 0::bigint)                        AS total_products,
       COALESCE(st.total_units_supplied, 0::bigint)                  AS total_stock,
       COALESCE(st.total_inventory_value, 0.00)                      AS total_purchased
FROM suppliers s
         LEFT JOIN countries c ON s.country_id = c.country_id
         LEFT JOIN ranked_products rp ON s.supplier_id = rp.supplier_id AND rp.rn = 1
         LEFT JOIN supplier_stats st ON s.supplier_id = st.supplier_id
WHERE s.active = true;

alter table view_suppliers_report
    owner to postgres;

