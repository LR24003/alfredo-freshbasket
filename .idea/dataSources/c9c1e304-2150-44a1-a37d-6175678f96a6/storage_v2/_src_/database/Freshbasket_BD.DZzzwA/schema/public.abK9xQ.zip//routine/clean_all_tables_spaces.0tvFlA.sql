create function clean_all_tables_spaces() returns trigger
    language plpgsql
as
$$
DECLARE
    col_name TEXT;
    col_value TEXT;
    updated_json JSONB;
BEGIN
    -- Inicializamos el JSONB con los datos del registro NEW
    updated_json := to_jsonb(NEW);

    -- Recorremos todas las columnas de tipo texto de la tabla que disparó el trigger
    FOR col_name IN 
        SELECT column_name 
        FROM information_schema.columns 
        WHERE table_schema = TG_TABLE_SCHEMA 
          AND table_name = TG_TABLE_NAME 
          AND data_type IN ('character varying', 'character', 'text')
    LOOP
        -- Extraemos el valor actual de la columna
        col_value := updated_json ->> col_name;
        
        -- Si el campo contiene texto, le aplicamos el TRIM
        IF col_value IS NOT NULL THEN
            updated_json := updated_json || jsonb_build_object(col_name, TRIM(col_value));
        END IF;
    END LOOP;

    -- CORRECCIÓN: Usamos jsonb_populate_record para que sea 100% compatible
    NEW := jsonb_populate_record(NEW, updated_json);

    RETURN NEW;
END;
$$;

alter function clean_all_tables_spaces() owner to postgres;

