create view view_sales_report
            (sale_id, sale_date, total_amount, payment_method, status, employee_id, employee_name, employee_email) as
SELECT s.sale_id,
       s.sale_date,
       s.total_amount,
       s.payment_method,
       s.status,
       s.employee_id,
       concat_ws(' '::text, u.name, u.last_name) AS employee_name,
       u.email                                   AS employee_email
FROM sales s
         JOIN users u ON s.employee_id = u.user_id
WHERE s.active = true;

alter table view_sales_report
    owner to postgres;

