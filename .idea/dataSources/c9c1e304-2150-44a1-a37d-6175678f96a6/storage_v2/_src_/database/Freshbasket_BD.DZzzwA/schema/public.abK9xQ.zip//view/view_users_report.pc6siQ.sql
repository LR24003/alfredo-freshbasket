create view view_users_report(user_id, full_name, email, role, active) as
SELECT user_id,
       concat_ws(' '::text, name, last_name) AS full_name,
       email,
       role,
       active
FROM users
WHERE active = true;

alter table view_users_report
    owner to postgres;

