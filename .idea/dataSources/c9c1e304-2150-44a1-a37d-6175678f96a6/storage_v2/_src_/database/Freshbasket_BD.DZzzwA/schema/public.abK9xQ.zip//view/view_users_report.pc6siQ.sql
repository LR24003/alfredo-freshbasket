create view view_users_report(user_id, full_name, email, role, estado, country_name) as
SELECT u.user_id,
       concat_ws(' '::text, u.name, u.last_name) AS full_name,
       u.email,
       u.role,
       CASE
           WHEN u.active = true THEN 'Activo'::text
           ELSE 'Inactivo'::text
           END                                   AS estado,
       c.name                                    AS country_name
FROM users u
         LEFT JOIN countries c ON u.country_id = c.country_id;

alter table view_users_report
    owner to postgres;

