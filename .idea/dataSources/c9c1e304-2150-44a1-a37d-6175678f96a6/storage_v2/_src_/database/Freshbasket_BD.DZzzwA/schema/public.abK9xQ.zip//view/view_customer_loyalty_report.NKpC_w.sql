create view view_customer_loyalty_report (customer_id, customer_name, customer_email, total_purchases, total_spent) as
SELECT u.user_id                                 AS customer_id,
       concat_ws(' '::text, u.name, u.last_name) AS customer_name,
       u.email                                   AS customer_email,
       count(s.sale_id)                          AS total_purchases,
       sum(s.total_amount)                       AS total_spent
FROM sales s
         JOIN users u ON s.customer_id = u.user_id
WHERE s.active = true
  AND s.status::text = 'Completada'::text
GROUP BY u.user_id, u.name, u.last_name, u.email
ORDER BY (sum(s.total_amount)) DESC;

alter table view_customer_loyalty_report
    owner to postgres;

