create view view_inventory_report
            (product_id, product_name, current_price, total_entries, total_exits, stock_available) as
SELECT p.product_id,
       p.name                                                                       AS product_name,
       p.price                                                                      AS current_price,
       COALESCE(sum(e.quantity), 0::bigint)                                         AS total_entries,
       COALESCE(sum(ex.quantity), 0::bigint)                                        AS total_exits,
       COALESCE(sum(e.quantity), 0::bigint) - COALESCE(sum(ex.quantity), 0::bigint) AS stock_available
FROM products p
         LEFT JOIN entries e ON p.product_id = e.product_id AND e.active = true
         LEFT JOIN exits ex ON p.product_id = ex.product_id AND ex.active = true
WHERE p.active = true
GROUP BY p.product_id, p.name, p.price;

alter table view_inventory_report
    owner to postgres;

