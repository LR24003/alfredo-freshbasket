create view view_inventory_report
            (product_id, product_name, current_price, total_entries, total_exits, stock_available) as
SELECT p.product_id,
       p.name                                  AS product_name,
       COALESCE(p.price, 0.00)::numeric(38, 2) AS current_price,
       COALESCE(e.total_entries, 0::bigint)    AS total_entries,
       COALESCE(ex.total_exits, 0::bigint)     AS total_exits,
       COALESCE(p.current_stock, 0)            AS stock_available
FROM products p
         LEFT JOIN (SELECT entries.product_id,
                           sum(entries.quantity) AS total_entries
                    FROM entries
                    WHERE entries.active = true
                    GROUP BY entries.product_id) e ON p.product_id = e.product_id
         LEFT JOIN (SELECT exits.product_id,
                           sum(exits.quantity) AS total_exits
                    FROM exits
                    WHERE exits.active = true
                    GROUP BY exits.product_id) ex ON p.product_id = ex.product_id
WHERE p.active = true
GROUP BY p.product_id, p.name, p.price, p.current_stock, e.total_entries, ex.total_exits;

alter table view_inventory_report
    owner to postgres;

