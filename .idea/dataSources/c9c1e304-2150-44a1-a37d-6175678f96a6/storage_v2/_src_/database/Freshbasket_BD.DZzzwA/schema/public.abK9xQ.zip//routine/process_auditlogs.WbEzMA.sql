create function process_auditlogs() returns trigger
    language plpgsql
as
$$
DECLARE
    session_user_id_str VARCHAR(255);
    final_user_display VARCHAR(255);
    resolved_entity_id BIGINT;
    final_action VARCHAR(20);
BEGIN
    -- 1. Capturar el ID de la sesión enviado por Spring Boot
    BEGIN
        session_user_id_str := NULLIF(current_setting('app.current_user_id', true), '');
    EXCEPTION WHEN OTHERS THEN
        session_user_id_str := NULL;
    END;

    -- 2. Buscar el nombre del usuario logueado en la tabla users
    IF session_user_id_str IS NOT NULL THEN
        SELECT CONCAT_WS(' ', name, last_name) INTO final_user_display
        FROM public.users 
        WHERE user_id = session_user_id_str::BIGINT;
        
        IF final_user_display IS NULL OR TRIM(final_user_display) = '' THEN
            final_user_display := 'Usuario ID: ' || session_user_id_str;
        END IF;
    ELSE
        IF TG_OP = 'INSERT' AND TG_TABLE_NAME = 'users' THEN
            SELECT CONCAT_WS(' ', NEW.name, NEW.last_name) || ' (Auto-registro)' INTO final_user_display;
        ELSE
            final_user_display := 'Sistema';
        END IF;
    END IF;

    -- 3. Mapeo TOTAL y EXPLÍCITO de llaves primarias por tabla
    IF (TG_OP = 'DELETE') THEN
        IF TG_TABLE_NAME = 'users' THEN resolved_entity_id := OLD.user_id;
        ELSIF TG_TABLE_NAME = 'categories' THEN resolved_entity_id := OLD.category_id;
        ELSIF TG_TABLE_NAME = 'products' THEN resolved_entity_id := OLD.product_id;
        ELSIF TG_TABLE_NAME = 'countries' THEN resolved_entity_id := OLD.country_id;
        ELSIF TG_TABLE_NAME = 'entries' THEN resolved_entity_id := OLD.entry_id;
        ELSIF TG_TABLE_NAME = 'exits' THEN resolved_entity_id := OLD.exit_id;
        ELSIF TG_TABLE_NAME = 'suppliers' THEN resolved_entity_id := OLD.supplier_id;
        ELSIF TG_TABLE_NAME = 'sales' OR TG_TABLE_NAME = 'Sales' THEN resolved_entity_id := OLD.sale_id;
        ELSIF TG_TABLE_NAME = 'sale_details' OR TG_TABLE_NAME = 'saledetail' THEN resolved_entity_id := OLD.detail_id;
        ELSIF TG_TABLE_NAME = 'cart' THEN resolved_entity_id := OLD.cart_id;
        ELSIF TG_TABLE_NAME = 'carrito' THEN resolved_entity_id := OLD.carrito_id;
        ELSE resolved_entity_id := OLD.id;
        END IF;
    ELSE
        IF TG_TABLE_NAME = 'users' THEN resolved_entity_id := NEW.user_id;
        ELSIF TG_TABLE_NAME = 'categories' THEN resolved_entity_id := NEW.category_id;
        ELSIF TG_TABLE_NAME = 'products' THEN resolved_entity_id := NEW.product_id;
        ELSIF TG_TABLE_NAME = 'countries' THEN resolved_entity_id := NEW.country_id;
        ELSIF TG_TABLE_NAME = 'entries' THEN resolved_entity_id := NEW.entry_id;
        ELSIF TG_TABLE_NAME = 'exits' THEN resolved_entity_id := NEW.exit_id;
        ELSIF TG_TABLE_NAME = 'suppliers' THEN resolved_entity_id := NEW.supplier_id;
        ELSIF TG_TABLE_NAME = 'sales' OR TG_TABLE_NAME = 'Sales' THEN resolved_entity_id := NEW.sale_id;
        ELSIF TG_TABLE_NAME = 'sale_details' OR TG_TABLE_NAME = 'saledetail' THEN resolved_entity_id := NEW.detail_id;
        ELSIF TG_TABLE_NAME = 'cart' THEN resolved_entity_id := NEW.cart_id;
        ELSIF TG_TABLE_NAME = 'carrito' THEN resolved_entity_id := NEW.carrito_id;
        ELSE resolved_entity_id := NEW.id;
        END IF;
    END IF;

    -- 4. DETECTAR BORRADO LÓGICO
    final_action := TG_OP; 

    IF TG_OP = 'UPDATE' THEN
        IF OLD.active = true AND NEW.active = false THEN
            final_action := 'DELETE';
        ELSIF OLD.active = false AND NEW.active = true THEN
            final_action := 'RESTORE'; 
        END IF;
    END IF;

    -- 5. Inserción en la tabla auditlogs
    INSERT INTO public.auditlogs (entity, entity_id, action, user_name, created_at)
    VALUES (TG_TABLE_NAME, resolved_entity_id, final_action, final_user_display, CURRENT_TIMESTAMP);

    -- 6. Retorno reglamentario
    IF (TG_OP = 'DELETE') THEN
        RETURN OLD;
    END IF;
    RETURN NEW;
END;
$$;

alter function process_auditlogs() owner to postgres;

