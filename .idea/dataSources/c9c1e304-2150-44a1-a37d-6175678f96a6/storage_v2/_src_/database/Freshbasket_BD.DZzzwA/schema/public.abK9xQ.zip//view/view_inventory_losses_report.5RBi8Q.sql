create view view_inventory_losses_report
            (exit_reason, product_id, product_name, total_units_lost, estimated_financial_loss) as
SELECT e.exit_reason,
       p.product_id,
       p.name                             AS product_name,
       sum(e.quantity)                    AS total_units_lost,
       sum(e.quantity::numeric * p.price) AS estimated_financial_loss
FROM exits e
         JOIN products p ON e.product_id = p.product_id
WHERE e.active = true
  AND e.exit_reason::text <> 'VENTA'::text
GROUP BY e.exit_reason, p.product_id, p.name
ORDER BY (sum(e.quantity::numeric * p.price)) DESC;

alter table view_inventory_losses_report
    owner to postgres;

