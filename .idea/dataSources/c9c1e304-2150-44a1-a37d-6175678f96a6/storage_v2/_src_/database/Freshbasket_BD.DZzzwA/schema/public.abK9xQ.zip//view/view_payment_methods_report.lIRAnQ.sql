create view view_payment_methods_report(payment_method, total_transactions, total_collected) as
SELECT payment_method,
       count(sale_id)    AS total_transactions,
       sum(total_amount) AS total_collected
FROM sales
WHERE active = true
  AND status::text = 'Completada'::text
GROUP BY payment_method
ORDER BY (sum(total_amount)) DESC;

alter table view_payment_methods_report
    owner to postgres;

