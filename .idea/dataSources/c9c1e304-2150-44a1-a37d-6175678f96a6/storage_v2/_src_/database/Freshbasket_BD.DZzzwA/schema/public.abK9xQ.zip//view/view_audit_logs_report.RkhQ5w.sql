create view view_audit_logs_report(audit_id, entity, entity_id, user_name, action, created_at) as
SELECT audit_id,
       entity,
       entity_id,
       user_name,
       action,
       created_at
FROM auditlogs
ORDER BY created_at DESC;

alter table view_audit_logs_report
    owner to postgres;

